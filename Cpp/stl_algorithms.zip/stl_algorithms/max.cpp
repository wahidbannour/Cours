#include <algorithm>
#include <iostream>
#include <iterator>
#include <vector>
using namespace std;

int main() {
  using std::max;
  cout << "max(1, 9999) : " << max(1, 9999) << endl;
  cout << "max('a', 'b'): " << max('a', 'b') << endl;
}
